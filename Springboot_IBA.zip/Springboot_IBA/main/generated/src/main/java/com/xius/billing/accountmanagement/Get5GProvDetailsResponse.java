
package com.xius.billing.accountmanagement;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for get5gProvDetailsResponse complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="get5gProvDetailsResponse">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="tariffid5gProv" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="atpid5gProv" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="nwid5gProv" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "get5gProvDetailsResponse", propOrder = {
    "tariffid5GProv",
    "atpid5GProv",
    "nwid5GProv"
})
public class Get5GProvDetailsResponse {

    @XmlElement(name = "tariffid5gProv")
    protected String tariffid5GProv;
    @XmlElement(name = "atpid5gProv")
    protected String atpid5GProv;
    @XmlElement(name = "nwid5gProv")
    protected String nwid5GProv;

    /**
     * Gets the value of the tariffid5GProv property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTariffid5GProv() {
        return tariffid5GProv;
    }

    /**
     * Sets the value of the tariffid5GProv property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTariffid5GProv(String value) {
        this.tariffid5GProv = value;
    }

    /**
     * Gets the value of the atpid5GProv property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAtpid5GProv() {
        return atpid5GProv;
    }

    /**
     * Sets the value of the atpid5GProv property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAtpid5GProv(String value) {
        this.atpid5GProv = value;
    }

    /**
     * Gets the value of the nwid5GProv property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNwid5GProv() {
        return nwid5GProv;
    }

    /**
     * Sets the value of the nwid5GProv property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNwid5GProv(String value) {
        this.nwid5GProv = value;
    }

}
