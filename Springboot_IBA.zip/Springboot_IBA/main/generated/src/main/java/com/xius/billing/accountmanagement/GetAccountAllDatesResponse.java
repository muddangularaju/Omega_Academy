
package com.xius.billing.accountmanagement;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for getAccountAllDatesResponse complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="getAccountAllDatesResponse">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="accountstatus" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="registrationdate" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="activationdate" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="validityDate" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="gracePeriod1EndDate" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="gracePeriod2EndDate" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="gracePeriod3EndDate" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="gracePeriod4EndDate" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="expiryDate" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "getAccountAllDatesResponse", propOrder = {
    "accountstatus",
    "registrationdate",
    "activationdate",
    "validityDate",
    "gracePeriod1EndDate",
    "gracePeriod2EndDate",
    "gracePeriod3EndDate",
    "gracePeriod4EndDate",
    "expiryDate"
})
public class GetAccountAllDatesResponse {

    protected String accountstatus;
    protected String registrationdate;
    protected String activationdate;
    protected String validityDate;
    protected String gracePeriod1EndDate;
    protected String gracePeriod2EndDate;
    protected String gracePeriod3EndDate;
    protected String gracePeriod4EndDate;
    protected String expiryDate;

    /**
     * Gets the value of the accountstatus property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAccountstatus() {
        return accountstatus;
    }

    /**
     * Sets the value of the accountstatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAccountstatus(String value) {
        this.accountstatus = value;
    }

    /**
     * Gets the value of the registrationdate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRegistrationdate() {
        return registrationdate;
    }

    /**
     * Sets the value of the registrationdate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRegistrationdate(String value) {
        this.registrationdate = value;
    }

    /**
     * Gets the value of the activationdate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getActivationdate() {
        return activationdate;
    }

    /**
     * Sets the value of the activationdate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setActivationdate(String value) {
        this.activationdate = value;
    }

    /**
     * Gets the value of the validityDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getValidityDate() {
        return validityDate;
    }

    /**
     * Sets the value of the validityDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setValidityDate(String value) {
        this.validityDate = value;
    }

    /**
     * Gets the value of the gracePeriod1EndDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getGracePeriod1EndDate() {
        return gracePeriod1EndDate;
    }

    /**
     * Sets the value of the gracePeriod1EndDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setGracePeriod1EndDate(String value) {
        this.gracePeriod1EndDate = value;
    }

    /**
     * Gets the value of the gracePeriod2EndDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getGracePeriod2EndDate() {
        return gracePeriod2EndDate;
    }

    /**
     * Sets the value of the gracePeriod2EndDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setGracePeriod2EndDate(String value) {
        this.gracePeriod2EndDate = value;
    }

    /**
     * Gets the value of the gracePeriod3EndDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getGracePeriod3EndDate() {
        return gracePeriod3EndDate;
    }

    /**
     * Sets the value of the gracePeriod3EndDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setGracePeriod3EndDate(String value) {
        this.gracePeriod3EndDate = value;
    }

    /**
     * Gets the value of the gracePeriod4EndDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getGracePeriod4EndDate() {
        return gracePeriod4EndDate;
    }

    /**
     * Sets the value of the gracePeriod4EndDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setGracePeriod4EndDate(String value) {
        this.gracePeriod4EndDate = value;
    }

    /**
     * Gets the value of the expiryDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getExpiryDate() {
        return expiryDate;
    }

    /**
     * Sets the value of the expiryDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setExpiryDate(String value) {
        this.expiryDate = value;
    }

}
