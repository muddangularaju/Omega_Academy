
package com.xius.billing.accountmanagement;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ChangeMSISDNsRequest complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ChangeMSISDNsRequest">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="hlrFlag" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="SIMSerialNos" type="{http://billing.xius.com/AccountManagement.xsd}SIMSerialNosType"/>
 *         &lt;element name="portInMSISDNs" type="{http://billing.xius.com/AccountManagement.xsd}MSISDNsType"/>
 *         &lt;element name="newRoutes" type="{http://billing.xius.com/AccountManagement.xsd}NewRoutesType" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ChangeMSISDNsRequest", propOrder = {
    "hlrFlag",
    "simSerialNos",
    "portInMSISDNs",
    "newRoutes"
})
public class ChangeMSISDNsRequest {

    protected Boolean hlrFlag;
    @XmlElement(name = "SIMSerialNos", required = true)
    protected SIMSerialNosType simSerialNos;
    @XmlElement(required = true)
    protected MSISDNsType portInMSISDNs;
    protected NewRoutesType newRoutes;

    /**
     * Gets the value of the hlrFlag property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isHlrFlag() {
        return hlrFlag;
    }

    /**
     * Sets the value of the hlrFlag property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setHlrFlag(Boolean value) {
        this.hlrFlag = value;
    }

    /**
     * Gets the value of the simSerialNos property.
     * 
     * @return
     *     possible object is
     *     {@link SIMSerialNosType }
     *     
     */
    public SIMSerialNosType getSIMSerialNos() {
        return simSerialNos;
    }

    /**
     * Sets the value of the simSerialNos property.
     * 
     * @param value
     *     allowed object is
     *     {@link SIMSerialNosType }
     *     
     */
    public void setSIMSerialNos(SIMSerialNosType value) {
        this.simSerialNos = value;
    }

    /**
     * Gets the value of the portInMSISDNs property.
     * 
     * @return
     *     possible object is
     *     {@link MSISDNsType }
     *     
     */
    public MSISDNsType getPortInMSISDNs() {
        return portInMSISDNs;
    }

    /**
     * Sets the value of the portInMSISDNs property.
     * 
     * @param value
     *     allowed object is
     *     {@link MSISDNsType }
     *     
     */
    public void setPortInMSISDNs(MSISDNsType value) {
        this.portInMSISDNs = value;
    }

    /**
     * Gets the value of the newRoutes property.
     * 
     * @return
     *     possible object is
     *     {@link NewRoutesType }
     *     
     */
    public NewRoutesType getNewRoutes() {
        return newRoutes;
    }

    /**
     * Sets the value of the newRoutes property.
     * 
     * @param value
     *     allowed object is
     *     {@link NewRoutesType }
     *     
     */
    public void setNewRoutes(NewRoutesType value) {
        this.newRoutes = value;
    }

}
