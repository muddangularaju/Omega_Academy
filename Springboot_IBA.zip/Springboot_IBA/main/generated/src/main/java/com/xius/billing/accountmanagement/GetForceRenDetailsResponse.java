
package com.xius.billing.accountmanagement;

import java.math.BigDecimal;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for getForceRenDetailsResponse complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="getForceRenDetailsResponse">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="oldTp" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="newTp" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="oldTpName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="newTpName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="oldTpCharge" type="{http://billing.xius.com/AccountManagement.xsd}CreditType" minOccurs="0"/>
 *         &lt;element name="newTpCharge" type="{http://billing.xius.com/AccountManagement.xsd}CreditType" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "getForceRenDetailsResponse", propOrder = {
    "oldTp",
    "newTp",
    "oldTpName",
    "newTpName",
    "oldTpCharge",
    "newTpCharge"
})
public class GetForceRenDetailsResponse {

    protected String oldTp;
    protected String newTp;
    protected String oldTpName;
    protected String newTpName;
    protected BigDecimal oldTpCharge;
    protected BigDecimal newTpCharge;

    /**
     * Gets the value of the oldTp property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOldTp() {
        return oldTp;
    }

    /**
     * Sets the value of the oldTp property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOldTp(String value) {
        this.oldTp = value;
    }

    /**
     * Gets the value of the newTp property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNewTp() {
        return newTp;
    }

    /**
     * Sets the value of the newTp property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNewTp(String value) {
        this.newTp = value;
    }

    /**
     * Gets the value of the oldTpName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOldTpName() {
        return oldTpName;
    }

    /**
     * Sets the value of the oldTpName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOldTpName(String value) {
        this.oldTpName = value;
    }

    /**
     * Gets the value of the newTpName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNewTpName() {
        return newTpName;
    }

    /**
     * Sets the value of the newTpName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNewTpName(String value) {
        this.newTpName = value;
    }

    /**
     * Gets the value of the oldTpCharge property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getOldTpCharge() {
        return oldTpCharge;
    }

    /**
     * Sets the value of the oldTpCharge property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setOldTpCharge(BigDecimal value) {
        this.oldTpCharge = value;
    }

    /**
     * Gets the value of the newTpCharge property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getNewTpCharge() {
        return newTpCharge;
    }

    /**
     * Sets the value of the newTpCharge property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setNewTpCharge(BigDecimal value) {
        this.newTpCharge = value;
    }

}
