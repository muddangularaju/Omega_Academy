
package com.xius.billing.accountmanagement;

import java.math.BigDecimal;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ChangeIMSIRequest complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ChangeIMSIRequest">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="account" type="{http://billing.xius.com/AccountManagement.xsd}AccountType"/>
 *         &lt;element name="newSerialNo" type="{http://billing.xius.com/AccountManagement.xsd}SerialNoType" minOccurs="0"/>
 *         &lt;element name="NewIMSI" type="{http://billing.xius.com/AccountManagement.xsd}IMSIType"/>
 *         &lt;element name="locationId" type="{http://billing.xius.com/AccountManagement.xsd}LocationIdType" minOccurs="0"/>
 *         &lt;element name="operator" type="{http://billing.xius.com/AccountManagement.xsd}OperatorType" minOccurs="0"/>
 *         &lt;element name="charges" type="{http://billing.xius.com/AccountManagement.xsd}ChargesType" minOccurs="0"/>
 *         &lt;element name="HLRFlag" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ChangeIMSIRequest", propOrder = {
    "account",
    "newSerialNo",
    "newIMSI",
    "locationId",
    "operator",
    "charges",
    "hlrFlag"
})
public class ChangeIMSIRequest {

    @XmlElement(required = true)
    protected AccountType account;
    protected String newSerialNo;
    @XmlElement(name = "NewIMSI", required = true)
    protected String newIMSI;
    protected Double locationId;
    protected String operator;
    protected BigDecimal charges;
    @XmlElement(name = "HLRFlag")
    protected Boolean hlrFlag;

    /**
     * Gets the value of the account property.
     * 
     * @return
     *     possible object is
     *     {@link AccountType }
     *     
     */
    public AccountType getAccount() {
        return account;
    }

    /**
     * Sets the value of the account property.
     * 
     * @param value
     *     allowed object is
     *     {@link AccountType }
     *     
     */
    public void setAccount(AccountType value) {
        this.account = value;
    }

    /**
     * Gets the value of the newSerialNo property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNewSerialNo() {
        return newSerialNo;
    }

    /**
     * Sets the value of the newSerialNo property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNewSerialNo(String value) {
        this.newSerialNo = value;
    }

    /**
     * Gets the value of the newIMSI property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNewIMSI() {
        return newIMSI;
    }

    /**
     * Sets the value of the newIMSI property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNewIMSI(String value) {
        this.newIMSI = value;
    }

    /**
     * Gets the value of the locationId property.
     * 
     * @return
     *     possible object is
     *     {@link Double }
     *     
     */
    public Double getLocationId() {
        return locationId;
    }

    /**
     * Sets the value of the locationId property.
     * 
     * @param value
     *     allowed object is
     *     {@link Double }
     *     
     */
    public void setLocationId(Double value) {
        this.locationId = value;
    }

    /**
     * Gets the value of the operator property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOperator() {
        return operator;
    }

    /**
     * Sets the value of the operator property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOperator(String value) {
        this.operator = value;
    }

    /**
     * Gets the value of the charges property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getCharges() {
        return charges;
    }

    /**
     * Sets the value of the charges property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setCharges(BigDecimal value) {
        this.charges = value;
    }

    /**
     * Gets the value of the hlrFlag property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isHLRFlag() {
        return hlrFlag;
    }

    /**
     * Sets the value of the hlrFlag property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setHLRFlag(Boolean value) {
        this.hlrFlag = value;
    }

}
