
package com.xius.billing.accountmanagement;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for GetTroubleTktHistoryRequest complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="GetTroubleTktHistoryRequest">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="tktNumber" type="{http://www.w3.org/2001/XMLSchema}long"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "GetTroubleTktHistoryRequest", propOrder = {
    "tktNumber"
})
public class GetTroubleTktHistoryRequest {

    protected long tktNumber;

    /**
     * Gets the value of the tktNumber property.
     * 
     */
    public long getTktNumber() {
        return tktNumber;
    }

    /**
     * Sets the value of the tktNumber property.
     * 
     */
    public void setTktNumber(long value) {
        this.tktNumber = value;
    }

}
