
package com.xius.billing.accountmanagement;

import java.math.BigDecimal;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ConvertAccountTypeRequest complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ConvertAccountTypeRequest">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="account" type="{http://billing.xius.com/AccountManagement.xsd}AccountType"/>
 *         &lt;element name="accountType" type="{http://billing.xius.com/AccountManagement.xsd}BillingType"/>
 *         &lt;element name="billingType" type="{http://billing.xius.com/AccountManagement.xsd}BillType" minOccurs="0"/>
 *         &lt;element name="billingFreq" type="{http://billing.xius.com/AccountManagement.xsd}BillFreqType" minOccurs="0"/>
 *         &lt;element name="creditLimit" type="{http://billing.xius.com/AccountManagement.xsd}CreditType" minOccurs="0"/>
 *         &lt;element name="billCycleDate" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="tariffPackageId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ConvertAccountTypeRequest", propOrder = {
    "account",
    "accountType",
    "billingType",
    "billingFreq",
    "creditLimit",
    "billCycleDate",
    "tariffPackageId"
})
public class ConvertAccountTypeRequest {

    @XmlElement(required = true)
    protected AccountType account;
    @XmlElement(required = true)
    protected BillingType accountType;
    protected String billingType;
    protected String billingFreq;
    protected BigDecimal creditLimit;
    protected String billCycleDate;
    protected Long tariffPackageId;

    /**
     * Gets the value of the account property.
     * 
     * @return
     *     possible object is
     *     {@link AccountType }
     *     
     */
    public AccountType getAccount() {
        return account;
    }

    /**
     * Sets the value of the account property.
     * 
     * @param value
     *     allowed object is
     *     {@link AccountType }
     *     
     */
    public void setAccount(AccountType value) {
        this.account = value;
    }

    /**
     * Gets the value of the accountType property.
     * 
     * @return
     *     possible object is
     *     {@link BillingType }
     *     
     */
    public BillingType getAccountType() {
        return accountType;
    }

    /**
     * Sets the value of the accountType property.
     * 
     * @param value
     *     allowed object is
     *     {@link BillingType }
     *     
     */
    public void setAccountType(BillingType value) {
        this.accountType = value;
    }

    /**
     * Gets the value of the billingType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBillingType() {
        return billingType;
    }

    /**
     * Sets the value of the billingType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBillingType(String value) {
        this.billingType = value;
    }

    /**
     * Gets the value of the billingFreq property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBillingFreq() {
        return billingFreq;
    }

    /**
     * Sets the value of the billingFreq property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBillingFreq(String value) {
        this.billingFreq = value;
    }

    /**
     * Gets the value of the creditLimit property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getCreditLimit() {
        return creditLimit;
    }

    /**
     * Sets the value of the creditLimit property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setCreditLimit(BigDecimal value) {
        this.creditLimit = value;
    }

    /**
     * Gets the value of the billCycleDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBillCycleDate() {
        return billCycleDate;
    }

    /**
     * Sets the value of the billCycleDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBillCycleDate(String value) {
        this.billCycleDate = value;
    }

    /**
     * Gets the value of the tariffPackageId property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getTariffPackageId() {
        return tariffPackageId;
    }

    /**
     * Sets the value of the tariffPackageId property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setTariffPackageId(Long value) {
        this.tariffPackageId = value;
    }

}
