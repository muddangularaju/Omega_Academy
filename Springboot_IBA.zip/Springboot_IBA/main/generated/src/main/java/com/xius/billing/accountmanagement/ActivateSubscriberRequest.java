
package com.xius.billing.accountmanagement;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ActivateSubscriberRequest complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ActivateSubscriberRequest">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;choice>
 *           &lt;element name="MSISDN" type="{http://billing.xius.com/AccountManagement.xsd}MSISDNType" minOccurs="0"/>
 *           &lt;element name="accountId" type="{http://billing.xius.com/AccountManagement.xsd}accountIdType" minOccurs="0"/>
 *         &lt;/choice>
 *         &lt;element name="RequestFrom" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ActiveSubscriber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ActivateSubscriberRequest", propOrder = {
    "msisdn",
    "accountId",
    "requestFrom",
    "activeSubscriber"
})
public class ActivateSubscriberRequest {

    @XmlElement(name = "MSISDN")
    protected String msisdn;
    protected String accountId;
    @XmlElement(name = "RequestFrom")
    protected String requestFrom;
    @XmlElement(name = "ActiveSubscriber")
    protected String activeSubscriber;

    /**
     * Gets the value of the msisdn property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMSISDN() {
        return msisdn;
    }

    /**
     * Sets the value of the msisdn property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMSISDN(String value) {
        this.msisdn = value;
    }

    /**
     * Gets the value of the accountId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAccountId() {
        return accountId;
    }

    /**
     * Sets the value of the accountId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAccountId(String value) {
        this.accountId = value;
    }

    /**
     * Gets the value of the requestFrom property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRequestFrom() {
        return requestFrom;
    }

    /**
     * Sets the value of the requestFrom property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRequestFrom(String value) {
        this.requestFrom = value;
    }

    /**
     * Gets the value of the activeSubscriber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getActiveSubscriber() {
        return activeSubscriber;
    }

    /**
     * Sets the value of the activeSubscriber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setActiveSubscriber(String value) {
        this.activeSubscriber = value;
    }

}
