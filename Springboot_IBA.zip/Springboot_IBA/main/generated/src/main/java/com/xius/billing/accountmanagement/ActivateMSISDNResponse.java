
package com.xius.billing.accountmanagement;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ActivateMSISDNResponse complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ActivateMSISDNResponse">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="MSISDN" type="{http://billing.xius.com/AccountManagement.xsd}MSISDNType" minOccurs="0"/>
 *         &lt;element name="IMSI" type="{http://billing.xius.com/AccountManagement.xsd}IMSIType" minOccurs="0"/>
 *         &lt;element name="isPostPaid" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="AccountID" type="{http://billing.xius.com/AccountManagement.xsd}AccountIdType" minOccurs="0"/>
 *         &lt;element name="isReactivate" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="isMOMTSrvcXst" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="isDataSrvcXst" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="optActivSrvcFlag" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ActivateMSISDNResponse", propOrder = {
    "msisdn",
    "imsi",
    "isPostPaid",
    "accountID",
    "isReactivate",
    "isMOMTSrvcXst",
    "isDataSrvcXst",
    "optActivSrvcFlag"
})
public class ActivateMSISDNResponse {

    @XmlElement(name = "MSISDN")
    protected String msisdn;
    @XmlElement(name = "IMSI")
    protected String imsi;
    protected String isPostPaid;
    @XmlElement(name = "AccountID")
    protected Long accountID;
    protected String isReactivate;
    protected String isMOMTSrvcXst;
    protected String isDataSrvcXst;
    protected String optActivSrvcFlag;

    /**
     * Gets the value of the msisdn property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMSISDN() {
        return msisdn;
    }

    /**
     * Sets the value of the msisdn property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMSISDN(String value) {
        this.msisdn = value;
    }

    /**
     * Gets the value of the imsi property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIMSI() {
        return imsi;
    }

    /**
     * Sets the value of the imsi property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIMSI(String value) {
        this.imsi = value;
    }

    /**
     * Gets the value of the isPostPaid property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIsPostPaid() {
        return isPostPaid;
    }

    /**
     * Sets the value of the isPostPaid property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIsPostPaid(String value) {
        this.isPostPaid = value;
    }

    /**
     * Gets the value of the accountID property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getAccountID() {
        return accountID;
    }

    /**
     * Sets the value of the accountID property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setAccountID(Long value) {
        this.accountID = value;
    }

    /**
     * Gets the value of the isReactivate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIsReactivate() {
        return isReactivate;
    }

    /**
     * Sets the value of the isReactivate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIsReactivate(String value) {
        this.isReactivate = value;
    }

    /**
     * Gets the value of the isMOMTSrvcXst property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIsMOMTSrvcXst() {
        return isMOMTSrvcXst;
    }

    /**
     * Sets the value of the isMOMTSrvcXst property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIsMOMTSrvcXst(String value) {
        this.isMOMTSrvcXst = value;
    }

    /**
     * Gets the value of the isDataSrvcXst property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIsDataSrvcXst() {
        return isDataSrvcXst;
    }

    /**
     * Sets the value of the isDataSrvcXst property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIsDataSrvcXst(String value) {
        this.isDataSrvcXst = value;
    }

    /**
     * Gets the value of the optActivSrvcFlag property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOptActivSrvcFlag() {
        return optActivSrvcFlag;
    }

    /**
     * Sets the value of the optActivSrvcFlag property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOptActivSrvcFlag(String value) {
        this.optActivSrvcFlag = value;
    }

}
