
package com.xius.billing.accountmanagement;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for CardProfilesListType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="CardProfilesListType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="ProfileData" type="{http://billing.xius.com/AccountManagement.xsd}ProfileDataType" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "CardProfilesListType", propOrder = {
    "profileData"
})
public class CardProfilesListType {

    @XmlElement(name = "ProfileData")
    protected ProfileDataType profileData;

    /**
     * Gets the value of the profileData property.
     * 
     * @return
     *     possible object is
     *     {@link ProfileDataType }
     *     
     */
    public ProfileDataType getProfileData() {
        return profileData;
    }

    /**
     * Sets the value of the profileData property.
     * 
     * @param value
     *     allowed object is
     *     {@link ProfileDataType }
     *     
     */
    public void setProfileData(ProfileDataType value) {
        this.profileData = value;
    }

}
