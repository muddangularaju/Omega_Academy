
package com.xius.billing.accountmanagement;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for GetMSISDNInfoResponse complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="GetMSISDNInfoResponse">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="subscribersList" type="{http://billing.xius.com/AccountManagement.xsd}SubscriberListType" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "GetMSISDNInfoResponse", propOrder = {
    "subscribersList"
})
public class GetMSISDNInfoResponse {

    protected SubscriberListType subscribersList;

    /**
     * Gets the value of the subscribersList property.
     * 
     * @return
     *     possible object is
     *     {@link SubscriberListType }
     *     
     */
    public SubscriberListType getSubscribersList() {
        return subscribersList;
    }

    /**
     * Sets the value of the subscribersList property.
     * 
     * @param value
     *     allowed object is
     *     {@link SubscriberListType }
     *     
     */
    public void setSubscribersList(SubscriberListType value) {
        this.subscribersList = value;
    }

}
