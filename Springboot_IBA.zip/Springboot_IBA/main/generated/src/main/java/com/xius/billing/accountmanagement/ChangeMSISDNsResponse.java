
package com.xius.billing.accountmanagement;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ChangeMSISDNsResponse complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ChangeMSISDNsResponse">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="message" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="countryCode" type="{http://billing.xius.com/AccountManagement.xsd}CountryCodeType" minOccurs="0"/>
 *         &lt;element name="transNo" type="{http://www.w3.org/2001/XMLSchema}long" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="MSISDNIMSIType" type="{http://www.w3.org/2001/XMLSchema}string" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="oldIMSI" type="{http://www.w3.org/2001/XMLSchema}string" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="subscriberState" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="oldCCNDCMsisdn" type="{http://billing.xius.com/AccountManagement.xsd}MSISDNsType" minOccurs="0"/>
 *         &lt;element name="newCCNDCMsisdn" type="{http://billing.xius.com/AccountManagement.xsd}MSISDNsType" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ChangeMSISDNsResponse", propOrder = {
    "message",
    "countryCode",
    "transNo",
    "msisdnimsiType",
    "oldIMSI",
    "subscriberState",
    "oldCCNDCMsisdn",
    "newCCNDCMsisdn"
})
public class ChangeMSISDNsResponse {

    @XmlElement(required = true)
    protected String message;
    protected String countryCode;
    @XmlElement(type = Long.class)
    protected List<Long> transNo;
    @XmlElement(name = "MSISDNIMSIType")
    protected List<String> msisdnimsiType;
    protected List<String> oldIMSI;
    protected String subscriberState;
    protected MSISDNsType oldCCNDCMsisdn;
    protected MSISDNsType newCCNDCMsisdn;

    /**
     * Gets the value of the message property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMessage() {
        return message;
    }

    /**
     * Sets the value of the message property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMessage(String value) {
        this.message = value;
    }

    /**
     * Gets the value of the countryCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCountryCode() {
        return countryCode;
    }

    /**
     * Sets the value of the countryCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCountryCode(String value) {
        this.countryCode = value;
    }

    /**
     * Gets the value of the transNo property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the transNo property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getTransNo().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Long }
     * 
     * 
     */
    public List<Long> getTransNo() {
        if (transNo == null) {
            transNo = new ArrayList<Long>();
        }
        return this.transNo;
    }

    /**
     * Gets the value of the msisdnimsiType property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the msisdnimsiType property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getMSISDNIMSIType().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link String }
     * 
     * 
     */
    public List<String> getMSISDNIMSIType() {
        if (msisdnimsiType == null) {
            msisdnimsiType = new ArrayList<String>();
        }
        return this.msisdnimsiType;
    }

    /**
     * Gets the value of the oldIMSI property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the oldIMSI property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getOldIMSI().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link String }
     * 
     * 
     */
    public List<String> getOldIMSI() {
        if (oldIMSI == null) {
            oldIMSI = new ArrayList<String>();
        }
        return this.oldIMSI;
    }

    /**
     * Gets the value of the subscriberState property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSubscriberState() {
        return subscriberState;
    }

    /**
     * Sets the value of the subscriberState property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSubscriberState(String value) {
        this.subscriberState = value;
    }

    /**
     * Gets the value of the oldCCNDCMsisdn property.
     * 
     * @return
     *     possible object is
     *     {@link MSISDNsType }
     *     
     */
    public MSISDNsType getOldCCNDCMsisdn() {
        return oldCCNDCMsisdn;
    }

    /**
     * Sets the value of the oldCCNDCMsisdn property.
     * 
     * @param value
     *     allowed object is
     *     {@link MSISDNsType }
     *     
     */
    public void setOldCCNDCMsisdn(MSISDNsType value) {
        this.oldCCNDCMsisdn = value;
    }

    /**
     * Gets the value of the newCCNDCMsisdn property.
     * 
     * @return
     *     possible object is
     *     {@link MSISDNsType }
     *     
     */
    public MSISDNsType getNewCCNDCMsisdn() {
        return newCCNDCMsisdn;
    }

    /**
     * Sets the value of the newCCNDCMsisdn property.
     * 
     * @param value
     *     allowed object is
     *     {@link MSISDNsType }
     *     
     */
    public void setNewCCNDCMsisdn(MSISDNsType value) {
        this.newCCNDCMsisdn = value;
    }

}
