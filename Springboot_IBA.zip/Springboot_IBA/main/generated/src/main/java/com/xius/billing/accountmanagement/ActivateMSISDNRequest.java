
package com.xius.billing.accountmanagement;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ActivateMSISDNRequest complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ActivateMSISDNRequest">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="activateMSISDN" type="{http://billing.xius.com/AccountManagement.xsd}activateMSISDNType"/>
 *         &lt;element name="parentMSISDN" type="{http://billing.xius.com/AccountManagement.xsd}MSISDNType"/>
 *         &lt;element name="IMSI" type="{http://billing.xius.com/AccountManagement.xsd}IMSIType" minOccurs="0"/>
 *         &lt;element name="IMEI" type="{http://billing.xius.com/AccountManagement.xsd}IMEIType" minOccurs="0"/>
 *         &lt;element name="cardProfile" type="{http://billing.xius.com/AccountManagement.xsd}CardProfileType"/>
 *         &lt;element name="zipCode" type="{http://billing.xius.com/AccountManagement.xsd}ZipCodeType"/>
 *         &lt;element name="MSISDN" type="{http://billing.xius.com/AccountManagement.xsd}MSISDNType"/>
 *         &lt;element name="postPaid" type="{http://billing.xius.com/AccountManagement.xsd}PostPaidType" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ActivateMSISDNRequest", propOrder = {
    "activateMSISDN",
    "parentMSISDN",
    "imsi",
    "imei",
    "cardProfile",
    "zipCode",
    "msisdn",
    "postPaid"
})
public class ActivateMSISDNRequest {

    @XmlElement(required = true)
    protected ActivateMSISDNType activateMSISDN;
    @XmlElement(required = true)
    protected String parentMSISDN;
    @XmlElement(name = "IMSI")
    protected String imsi;
    @XmlElement(name = "IMEI")
    protected String imei;
    protected long cardProfile;
    @XmlElement(required = true)
    protected String zipCode;
    @XmlElement(name = "MSISDN", required = true)
    protected String msisdn;
    @XmlElement(defaultValue = "N")
    protected String postPaid;

    /**
     * Gets the value of the activateMSISDN property.
     * 
     * @return
     *     possible object is
     *     {@link ActivateMSISDNType }
     *     
     */
    public ActivateMSISDNType getActivateMSISDN() {
        return activateMSISDN;
    }

    /**
     * Sets the value of the activateMSISDN property.
     * 
     * @param value
     *     allowed object is
     *     {@link ActivateMSISDNType }
     *     
     */
    public void setActivateMSISDN(ActivateMSISDNType value) {
        this.activateMSISDN = value;
    }

    /**
     * Gets the value of the parentMSISDN property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getParentMSISDN() {
        return parentMSISDN;
    }

    /**
     * Sets the value of the parentMSISDN property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setParentMSISDN(String value) {
        this.parentMSISDN = value;
    }

    /**
     * Gets the value of the imsi property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIMSI() {
        return imsi;
    }

    /**
     * Sets the value of the imsi property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIMSI(String value) {
        this.imsi = value;
    }

    /**
     * Gets the value of the imei property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIMEI() {
        return imei;
    }

    /**
     * Sets the value of the imei property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIMEI(String value) {
        this.imei = value;
    }

    /**
     * Gets the value of the cardProfile property.
     * 
     */
    public long getCardProfile() {
        return cardProfile;
    }

    /**
     * Sets the value of the cardProfile property.
     * 
     */
    public void setCardProfile(long value) {
        this.cardProfile = value;
    }

    /**
     * Gets the value of the zipCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getZipCode() {
        return zipCode;
    }

    /**
     * Sets the value of the zipCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setZipCode(String value) {
        this.zipCode = value;
    }

    /**
     * Gets the value of the msisdn property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMSISDN() {
        return msisdn;
    }

    /**
     * Sets the value of the msisdn property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMSISDN(String value) {
        this.msisdn = value;
    }

    /**
     * Gets the value of the postPaid property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPostPaid() {
        return postPaid;
    }

    /**
     * Sets the value of the postPaid property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPostPaid(String value) {
        this.postPaid = value;
    }

}
