
package com.xius.billing.accountmanagement;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for GetAdditionalServicesResponse complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="GetAdditionalServicesResponse">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="services" type="{http://billing.xius.com/AccountManagement.xsd}AddtnalServcListType" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "GetAdditionalServicesResponse", propOrder = {
    "services"
})
public class GetAdditionalServicesResponse {

    protected AddtnalServcListType services;

    /**
     * Gets the value of the services property.
     * 
     * @return
     *     possible object is
     *     {@link AddtnalServcListType }
     *     
     */
    public AddtnalServcListType getServices() {
        return services;
    }

    /**
     * Sets the value of the services property.
     * 
     * @param value
     *     allowed object is
     *     {@link AddtnalServcListType }
     *     
     */
    public void setServices(AddtnalServcListType value) {
        this.services = value;
    }

}
