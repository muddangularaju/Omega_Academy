
package com.xius.billing.accountmanagement;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for accountStatusType.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="accountStatusType">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="ACTIVE"/>
 *     &lt;enumeration value="G2"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "accountStatusType")
@XmlEnum
public enum AccountStatusType {

    ACTIVE("ACTIVE"),
    @XmlEnumValue("G2")
    G_2("G2");
    private final String value;

    AccountStatusType(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static AccountStatusType fromValue(String v) {
        for (AccountStatusType c: AccountStatusType.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
