
package com.xius.billing.accountmanagement;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for GetMSISDNInfoRequest complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="GetMSISDNInfoRequest">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="subscriberList" type="{http://billing.xius.com/AccountManagement.xsd}SubscriberListType" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "GetMSISDNInfoRequest", propOrder = {
    "subscriberList"
})
public class GetMSISDNInfoRequest {

    protected SubscriberListType subscriberList;

    /**
     * Gets the value of the subscriberList property.
     * 
     * @return
     *     possible object is
     *     {@link SubscriberListType }
     *     
     */
    public SubscriberListType getSubscriberList() {
        return subscriberList;
    }

    /**
     * Sets the value of the subscriberList property.
     * 
     * @param value
     *     allowed object is
     *     {@link SubscriberListType }
     *     
     */
    public void setSubscriberList(SubscriberListType value) {
        this.subscriberList = value;
    }

}
