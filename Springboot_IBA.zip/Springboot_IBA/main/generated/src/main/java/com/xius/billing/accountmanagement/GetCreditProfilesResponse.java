
package com.xius.billing.accountmanagement;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for GetCreditProfilesResponse complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="GetCreditProfilesResponse">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="creditProfiles" type="{http://billing.xius.com/AccountManagement.xsd}CreditProfilesType" minOccurs="0"/>
 *         &lt;element name="cardProfiles" type="{http://billing.xius.com/AccountManagement.xsd}CardProfilesType" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "GetCreditProfilesResponse", propOrder = {
    "creditProfiles",
    "cardProfiles"
})
public class GetCreditProfilesResponse {

    protected CreditProfilesType creditProfiles;
    protected CardProfilesType cardProfiles;

    /**
     * Gets the value of the creditProfiles property.
     * 
     * @return
     *     possible object is
     *     {@link CreditProfilesType }
     *     
     */
    public CreditProfilesType getCreditProfiles() {
        return creditProfiles;
    }

    /**
     * Sets the value of the creditProfiles property.
     * 
     * @param value
     *     allowed object is
     *     {@link CreditProfilesType }
     *     
     */
    public void setCreditProfiles(CreditProfilesType value) {
        this.creditProfiles = value;
    }

    /**
     * Gets the value of the cardProfiles property.
     * 
     * @return
     *     possible object is
     *     {@link CardProfilesType }
     *     
     */
    public CardProfilesType getCardProfiles() {
        return cardProfiles;
    }

    /**
     * Sets the value of the cardProfiles property.
     * 
     * @param value
     *     allowed object is
     *     {@link CardProfilesType }
     *     
     */
    public void setCardProfiles(CardProfilesType value) {
        this.cardProfiles = value;
    }

}
