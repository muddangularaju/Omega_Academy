
package com.xius.billing.accountmanagement;

import java.math.BigDecimal;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ChangeIMSIPreInfoResponse complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ChangeIMSIPreInfoResponse">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="currentIMSI" type="{http://billing.xius.com/AccountManagement.xsd}IMSIType" minOccurs="0"/>
 *         &lt;element name="currSerialNo" type="{http://billing.xius.com/AccountManagement.xsd}IMSIType" minOccurs="0"/>
 *         &lt;element name="currentBalance" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ChangeIMSIPreInfoResponse", propOrder = {
    "currentIMSI",
    "currSerialNo",
    "currentBalance"
})
public class ChangeIMSIPreInfoResponse {

    protected String currentIMSI;
    protected String currSerialNo;
    protected BigDecimal currentBalance;

    /**
     * Gets the value of the currentIMSI property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCurrentIMSI() {
        return currentIMSI;
    }

    /**
     * Sets the value of the currentIMSI property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCurrentIMSI(String value) {
        this.currentIMSI = value;
    }

    /**
     * Gets the value of the currSerialNo property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCurrSerialNo() {
        return currSerialNo;
    }

    /**
     * Sets the value of the currSerialNo property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCurrSerialNo(String value) {
        this.currSerialNo = value;
    }

    /**
     * Gets the value of the currentBalance property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getCurrentBalance() {
        return currentBalance;
    }

    /**
     * Sets the value of the currentBalance property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setCurrentBalance(BigDecimal value) {
        this.currentBalance = value;
    }

}
