
package com.xius.billing.accountmanagement;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for AddtionalServiceType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="AddtionalServiceType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="serviceId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="serviceName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="airTimeCalId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="airTimeCalName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="pstnCalId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="pstnCalName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "AddtionalServiceType", propOrder = {
    "serviceId",
    "serviceName",
    "airTimeCalId",
    "airTimeCalName",
    "pstnCalId",
    "pstnCalName"
})
public class AddtionalServiceType {

    protected Long serviceId;
    protected String serviceName;
    protected Long airTimeCalId;
    protected String airTimeCalName;
    protected Long pstnCalId;
    protected String pstnCalName;

    /**
     * Gets the value of the serviceId property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getServiceId() {
        return serviceId;
    }

    /**
     * Sets the value of the serviceId property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setServiceId(Long value) {
        this.serviceId = value;
    }

    /**
     * Gets the value of the serviceName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getServiceName() {
        return serviceName;
    }

    /**
     * Sets the value of the serviceName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setServiceName(String value) {
        this.serviceName = value;
    }

    /**
     * Gets the value of the airTimeCalId property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getAirTimeCalId() {
        return airTimeCalId;
    }

    /**
     * Sets the value of the airTimeCalId property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setAirTimeCalId(Long value) {
        this.airTimeCalId = value;
    }

    /**
     * Gets the value of the airTimeCalName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAirTimeCalName() {
        return airTimeCalName;
    }

    /**
     * Sets the value of the airTimeCalName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAirTimeCalName(String value) {
        this.airTimeCalName = value;
    }

    /**
     * Gets the value of the pstnCalId property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getPstnCalId() {
        return pstnCalId;
    }

    /**
     * Sets the value of the pstnCalId property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setPstnCalId(Long value) {
        this.pstnCalId = value;
    }

    /**
     * Gets the value of the pstnCalName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPstnCalName() {
        return pstnCalName;
    }

    /**
     * Sets the value of the pstnCalName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPstnCalName(String value) {
        this.pstnCalName = value;
    }

}
