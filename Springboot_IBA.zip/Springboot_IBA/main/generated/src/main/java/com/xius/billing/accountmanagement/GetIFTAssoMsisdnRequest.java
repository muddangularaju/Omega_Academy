
package com.xius.billing.accountmanagement;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for GetIFTAssoMsisdnRequest complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="GetIFTAssoMsisdnRequest">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="locationcode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="IMSI" type="{http://billing.xius.com/AccountManagement.xsd}IMSIType" minOccurs="0"/>
 *         &lt;element name="MSISDN" type="{http://billing.xius.com/AccountManagement.xsd}MSISDNType" minOccurs="0"/>
 *         &lt;element name="SIMNO" type="{http://billing.xius.com/AccountManagement.xsd}SIMType" minOccurs="0"/>
 *         &lt;element name="NIR" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="SNA" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "GetIFTAssoMsisdnRequest", propOrder = {
    "locationcode",
    "imsi",
    "msisdn",
    "simno",
    "nir",
    "sna"
})
public class GetIFTAssoMsisdnRequest {

    protected String locationcode;
    @XmlElement(name = "IMSI")
    protected String imsi;
    @XmlElement(name = "MSISDN")
    protected String msisdn;
    @XmlElement(name = "SIMNO")
    protected String simno;
    @XmlElement(name = "NIR")
    protected Long nir;
    @XmlElement(name = "SNA")
    protected Long sna;

    /**
     * Gets the value of the locationcode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLocationcode() {
        return locationcode;
    }

    /**
     * Sets the value of the locationcode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLocationcode(String value) {
        this.locationcode = value;
    }

    /**
     * Gets the value of the imsi property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIMSI() {
        return imsi;
    }

    /**
     * Sets the value of the imsi property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIMSI(String value) {
        this.imsi = value;
    }

    /**
     * Gets the value of the msisdn property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMSISDN() {
        return msisdn;
    }

    /**
     * Sets the value of the msisdn property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMSISDN(String value) {
        this.msisdn = value;
    }

    /**
     * Gets the value of the simno property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSIMNO() {
        return simno;
    }

    /**
     * Sets the value of the simno property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSIMNO(String value) {
        this.simno = value;
    }

    /**
     * Gets the value of the nir property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getNIR() {
        return nir;
    }

    /**
     * Sets the value of the nir property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setNIR(Long value) {
        this.nir = value;
    }

    /**
     * Gets the value of the sna property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getSNA() {
        return sna;
    }

    /**
     * Sets the value of the sna property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setSNA(Long value) {
        this.sna = value;
    }

}
