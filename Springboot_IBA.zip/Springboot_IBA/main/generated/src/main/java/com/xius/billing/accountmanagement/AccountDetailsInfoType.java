
package com.xius.billing.accountmanagement;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for accountDetailsInfoType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="accountDetailsInfoType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="oldAccountId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="newAccountId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="oldMSISDN" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="newMSISDN" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="oldIMSI" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="newIMSI" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="oldSIM" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="newSIM" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "accountDetailsInfoType", propOrder = {
    "oldAccountId",
    "newAccountId",
    "oldMSISDN",
    "newMSISDN",
    "oldIMSI",
    "newIMSI",
    "oldSIM",
    "newSIM"
})
public class AccountDetailsInfoType {

    protected Long oldAccountId;
    protected Long newAccountId;
    protected Long oldMSISDN;
    protected Long newMSISDN;
    protected Long oldIMSI;
    protected Long newIMSI;
    protected String oldSIM;
    protected String newSIM;

    /**
     * Gets the value of the oldAccountId property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getOldAccountId() {
        return oldAccountId;
    }

    /**
     * Sets the value of the oldAccountId property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setOldAccountId(Long value) {
        this.oldAccountId = value;
    }

    /**
     * Gets the value of the newAccountId property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getNewAccountId() {
        return newAccountId;
    }

    /**
     * Sets the value of the newAccountId property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setNewAccountId(Long value) {
        this.newAccountId = value;
    }

    /**
     * Gets the value of the oldMSISDN property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getOldMSISDN() {
        return oldMSISDN;
    }

    /**
     * Sets the value of the oldMSISDN property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setOldMSISDN(Long value) {
        this.oldMSISDN = value;
    }

    /**
     * Gets the value of the newMSISDN property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getNewMSISDN() {
        return newMSISDN;
    }

    /**
     * Sets the value of the newMSISDN property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setNewMSISDN(Long value) {
        this.newMSISDN = value;
    }

    /**
     * Gets the value of the oldIMSI property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getOldIMSI() {
        return oldIMSI;
    }

    /**
     * Sets the value of the oldIMSI property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setOldIMSI(Long value) {
        this.oldIMSI = value;
    }

    /**
     * Gets the value of the newIMSI property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getNewIMSI() {
        return newIMSI;
    }

    /**
     * Sets the value of the newIMSI property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setNewIMSI(Long value) {
        this.newIMSI = value;
    }

    /**
     * Gets the value of the oldSIM property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOldSIM() {
        return oldSIM;
    }

    /**
     * Sets the value of the oldSIM property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOldSIM(String value) {
        this.oldSIM = value;
    }

    /**
     * Gets the value of the newSIM property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNewSIM() {
        return newSIM;
    }

    /**
     * Sets the value of the newSIM property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNewSIM(String value) {
        this.newSIM = value;
    }

}
