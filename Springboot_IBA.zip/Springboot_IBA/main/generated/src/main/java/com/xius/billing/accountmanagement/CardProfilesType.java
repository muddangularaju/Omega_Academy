
package com.xius.billing.accountmanagement;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for CardProfilesType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="CardProfilesType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="available" type="{http://billing.xius.com/AccountManagement.xsd}CardProfilesListType" maxOccurs="unbounded"/>
 *         &lt;element name="assigned" type="{http://billing.xius.com/AccountManagement.xsd}CardProfilesListType" maxOccurs="unbounded"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "CardProfilesType", propOrder = {
    "available",
    "assigned"
})
public class CardProfilesType {

    @XmlElement(required = true)
    protected List<CardProfilesListType> available;
    @XmlElement(required = true)
    protected List<CardProfilesListType> assigned;

    /**
     * Gets the value of the available property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the available property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getAvailable().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link CardProfilesListType }
     * 
     * 
     */
    public List<CardProfilesListType> getAvailable() {
        if (available == null) {
            available = new ArrayList<CardProfilesListType>();
        }
        return this.available;
    }

    /**
     * Gets the value of the assigned property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the assigned property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getAssigned().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link CardProfilesListType }
     * 
     * 
     */
    public List<CardProfilesListType> getAssigned() {
        if (assigned == null) {
            assigned = new ArrayList<CardProfilesListType>();
        }
        return this.assigned;
    }

}
