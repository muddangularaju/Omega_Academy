
package com.xius.billing.accountmanagement;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for GetPathInfoResponse complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="GetPathInfoResponse">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="pathDetails" type="{http://billing.xius.com/AccountManagement.xsd}PathDetailsType" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "GetPathInfoResponse", propOrder = {
    "pathDetails"
})
public class GetPathInfoResponse {

    protected PathDetailsType pathDetails;

    /**
     * Gets the value of the pathDetails property.
     * 
     * @return
     *     possible object is
     *     {@link PathDetailsType }
     *     
     */
    public PathDetailsType getPathDetails() {
        return pathDetails;
    }

    /**
     * Sets the value of the pathDetails property.
     * 
     * @param value
     *     allowed object is
     *     {@link PathDetailsType }
     *     
     */
    public void setPathDetails(PathDetailsType value) {
        this.pathDetails = value;
    }

}
