
package com.xius.billing.accountmanagement;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for corpTpProdGetUpdateResponse complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="corpTpProdGetUpdateResponse">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="transactionId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="oldProdId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="newProdId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "corpTpProdGetUpdateResponse", propOrder = {
    "transactionId",
    "oldProdId",
    "newProdId"
})
public class CorpTpProdGetUpdateResponse {

    protected String transactionId;
    protected String oldProdId;
    protected String newProdId;

    /**
     * Gets the value of the transactionId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTransactionId() {
        return transactionId;
    }

    /**
     * Sets the value of the transactionId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTransactionId(String value) {
        this.transactionId = value;
    }

    /**
     * Gets the value of the oldProdId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOldProdId() {
        return oldProdId;
    }

    /**
     * Sets the value of the oldProdId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOldProdId(String value) {
        this.oldProdId = value;
    }

    /**
     * Gets the value of the newProdId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNewProdId() {
        return newProdId;
    }

    /**
     * Sets the value of the newProdId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNewProdId(String value) {
        this.newProdId = value;
    }

}
