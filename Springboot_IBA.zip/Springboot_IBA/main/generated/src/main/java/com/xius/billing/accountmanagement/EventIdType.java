
package com.xius.billing.accountmanagement;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for eventIdType.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="eventIdType">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="SIMSWAP"/>
 *     &lt;enumeration value="CHNGMSISDN"/>
 *     &lt;enumeration value="CREATE_ACCOUNT"/>
 *     &lt;enumeration value="CREATE_SUBSCRIBER"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "eventIdType")
@XmlEnum
public enum EventIdType {

    SIMSWAP,
    CHNGMSISDN,
    CREATE_ACCOUNT,
    CREATE_SUBSCRIBER;

    public String value() {
        return name();
    }

    public static EventIdType fromValue(String v) {
        return valueOf(v);
    }

}
