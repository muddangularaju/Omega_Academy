
package com.xius.billing.accountmanagement;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for getAccountDatesResponse complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="getAccountDatesResponse">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="validityDate" type="{http://billing.xius.com/AccountManagement.xsd}DDMONYYYYFormat" minOccurs="0"/>
 *         &lt;element name="gracePeriod1EndDate" type="{http://billing.xius.com/AccountManagement.xsd}DDMONYYYYFormat" minOccurs="0"/>
 *         &lt;element name="gracePeriod2EndDate" type="{http://billing.xius.com/AccountManagement.xsd}DDMONYYYYFormat" minOccurs="0"/>
 *         &lt;element name="expiryDate" type="{http://billing.xius.com/AccountManagement.xsd}DDMONYYYYFormat" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "getAccountDatesResponse", propOrder = {
    "validityDate",
    "gracePeriod1EndDate",
    "gracePeriod2EndDate",
    "expiryDate"
})
public class GetAccountDatesResponse {

    protected String validityDate;
    protected String gracePeriod1EndDate;
    protected String gracePeriod2EndDate;
    protected String expiryDate;

    /**
     * Gets the value of the validityDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getValidityDate() {
        return validityDate;
    }

    /**
     * Sets the value of the validityDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setValidityDate(String value) {
        this.validityDate = value;
    }

    /**
     * Gets the value of the gracePeriod1EndDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getGracePeriod1EndDate() {
        return gracePeriod1EndDate;
    }

    /**
     * Sets the value of the gracePeriod1EndDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setGracePeriod1EndDate(String value) {
        this.gracePeriod1EndDate = value;
    }

    /**
     * Gets the value of the gracePeriod2EndDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getGracePeriod2EndDate() {
        return gracePeriod2EndDate;
    }

    /**
     * Sets the value of the gracePeriod2EndDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setGracePeriod2EndDate(String value) {
        this.gracePeriod2EndDate = value;
    }

    /**
     * Gets the value of the expiryDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getExpiryDate() {
        return expiryDate;
    }

    /**
     * Sets the value of the expiryDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setExpiryDate(String value) {
        this.expiryDate = value;
    }

}
